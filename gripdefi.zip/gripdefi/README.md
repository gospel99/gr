# gripdefi

paste address di akun.txt

dah tinggal crot
DWYOR
